var searchData=
[
  ['application',['application',['../namespace_main.html#aa7a98334f797bba10c4d74760d00b156',1,'Main.application()'],['../namespace_main___balance___board.html#a6980752bb7dab882b56548530c168dc4',1,'Main_Balance_Board.application()']]]
];
